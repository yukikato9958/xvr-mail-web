namespace MailViewer.Core.Providers;

/// <summary>
/// IMAP routing for known domains, including a documented Japan provider catalog.
/// Unknown domains use common IMAP hostname patterns; manual settings remain available.
/// </summary>
public static class ImapServerMap
{
    /// <summary>(hostname, port, useSSL)</summary>
    public static readonly Dictionary<string, (string Host, int Port, bool UseSsl)> Servers = new(StringComparer.OrdinalIgnoreCase)
    {
        // ──── Microsoft (IMAP server reference; may require OAuth) ────
        ["hotmail.com"] = ("outlook.office365.com", 993, true),
        ["outlook.com"] = ("outlook.office365.com", 993, true),
        ["live.com"] = ("outlook.office365.com", 993, true),
        ["msn.com"] = ("outlook.office365.com", 993, true),
        // kunimine.co.jp MX points to Microsoft 365 Exchange Online.
        // Note: Outlook IMAP needs OAuth 2.0. XVR currently has no Microsoft OAuth flow.
        ["kunimine.co.jp"] = ("outlook.office365.com", 993, true),

        // ──── Google ────
        ["gmail.com"] = ("imap.gmail.com", 993, true),
        ["googlemail.com"] = ("imap.gmail.com", 993, true),

        // ──── Yahoo ────
        ["yahoo.com"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.co.uk"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.co.jp"] = ("imap.mail.yahoo.co.jp", 993, true), // Yahoo! JAPAN differs from Yahoo global
        ["ymail.ne.jp"] = ("imap.mail.yahoo.co.jp", 993, true), // Yahoo! JAPAN alias
        ["ybb.ne.jp"] = ("imap.mail.yahoo.co.jp", 993, true), // Yahoo! BB, may need a different IMAP username
        ["yahoo.ne.jp"] = ("ymobileimap.mail.yahoo.ne.jp", 993, true), // Y!mobile: official guide excludes PC support
        ["yahoo.fr"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.de"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.it"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.es"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.ca"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.com.au"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.com.br"] = ("imap.mail.yahoo.com", 993, true),
        ["yahoo.co.in"] = ("imap.mail.yahoo.com", 993, true),
        ["ymail.com"] = ("imap.mail.yahoo.com", 993, true),
        ["rocketmail.com"] = ("imap.mail.yahoo.com", 993, true),

        // ──── AOL / Verizon ────
        ["aol.com"] = ("imap.aol.com", 993, true),
        ["aim.com"] = ("imap.aol.com", 993, true),
        ["verizon.net"] = ("incoming.verizon.net", 993, true),

        // ──── Apple ────
        ["icloud.com"] = ("imap.mail.me.com", 993, true),
        ["me.com"] = ("imap.mail.me.com", 993, true),
        ["mac.com"] = ("imap.mail.me.com", 993, true),

        // ──── German Providers ────
        ["gmx.com"] = ("imap.gmx.com", 993, true),
        ["gmx.de"] = ("imap.gmx.net", 993, true),
        ["gmx.net"] = ("imap.gmx.net", 993, true),
        ["gmx.at"] = ("imap.gmx.net", 993, true),
        ["gmx.ch"] = ("imap.gmx.net", 993, true),
        ["web.de"] = ("imap.web.de", 993, true),
        ["t-online.de"] = ("secureimap.t-online.de", 993, true),
        ["freenet.de"] = ("mx.freenet.de", 993, true),
        ["arcor.de"] = ("imap.arcor.de", 993, true),
        ["posteo.de"] = ("posteo.de", 993, true),

        // ──── French Providers ────
        ["orange.fr"] = ("imap.orange.fr", 993, true),
        ["wanadoo.fr"] = ("imap.orange.fr", 993, true),
        ["laposte.net"] = ("imap.laposte.net", 993, true),
        ["sfr.fr"] = ("imap.sfr.fr", 993, true),
        ["free.fr"] = ("imap.free.fr", 993, true),

        // ──── Italian Providers ────
        ["libero.it"] = ("imapmail.libero.it", 993, true),
        ["virgilio.it"] = ("in.virgilio.it", 993, true),
        ["alice.it"] = ("in.alice.it", 993, true),
        ["tin.it"] = ("in.alice.it", 993, true),
        ["tiscali.it"] = ("imap.tiscali.it", 993, true),

        // ──── Russian Providers ────
        ["mail.ru"] = ("imap.mail.ru", 993, true),
        ["inbox.ru"] = ("imap.mail.ru", 993, true),
        ["list.ru"] = ("imap.mail.ru", 993, true),
        ["bk.ru"] = ("imap.mail.ru", 993, true),
        ["yandex.ru"] = ("imap.yandex.ru", 993, true),
        ["yandex.com"] = ("imap.yandex.com", 993, true),
        ["ya.ru"] = ("imap.yandex.ru", 993, true),
        ["rambler.ru"] = ("imap.rambler.ru", 993, true),

        // ──── Spanish / Portuguese ────
        ["terra.com.br"] = ("imap.terra.com.br", 993, true),
        ["uol.com.br"] = ("imap.uol.com.br", 993, true),
        ["bol.com.br"] = ("imap.bol.com.br", 993, true),

        // ──── Chinese Providers ────
        ["qq.com"] = ("imap.qq.com", 993, true),
        // Tencent Enterprise Mail (Exmail), confirmed by jimaytex.com MX records.
        // IMAP host per Tencent help: https://service.rtxmail.net/help/234.html
        ["jimaytex.com"] = ("imap.exmail.qq.com", 993, true),
        ["163.com"] = ("imap.163.com", 993, true),
        ["126.com"] = ("imap.126.com", 993, true),
        ["sina.com"] = ("imap.sina.com", 993, true),
        ["sina.cn"] = ("imap.sina.com", 993, true),
        ["yeah.net"] = ("imap.yeah.net", 993, true),
        ["foxmail.com"] = ("imap.qq.com", 993, true),
        ["aliyun.com"] = ("imap.aliyun.com", 993, true),

        // ──── Japanese Providers ────
        // Official provider hostnames. These use SSL/TLS on port 993.
        // Edion Net: https://www.enjoy.jp/cs/tech/mail.html
        ["enjoy.ne.jp"] = ("imaps.enjoy.ne.jp", 993, true),
        ["fkym.enjoy.ne.jp"] = ("imaps.enjoy.ne.jp", 993, true), // Explicit alias observed in XVR login; other subdomains use suffix routing
        // BB4U: https://ics.bb4u.ne.jp/iuc/faqnew.php?ID=533
        // BB4U IMAP host: SSL/TLS port 993. Applies to *.bb4u.ne.jp addresses.
        ["bb4u.ne.jp"] = ("mbox.mose-mail.jp", 993, true),
        ["pycm.bb4u.ne.jp"] = ("mbox.mose-mail.jp", 993, true),
        // ZAQ: https://cs.zaq.ne.jp/ (IMAP setup guidance)
        ["zaq.ne.jp"] = ("imap-f.zaq.ne.jp", 993, true),
        // Hanno Hidaka Television uses ZAQ MX hosts (mgw1/mgw2.mx.zaq.ne.jp).
        // ZAQ's published IMAP endpoint is a provider-level candidate; login not verified for hanno.jp.
        ["hanno.jp"] = ("imap-f.zaq.ne.jp", 993, true),
        ["tanet.ne.jp"] = ("imap-f.zaq.ne.jp", 993, true),
        // Tokyo Cable Network / ZAQ (not the general catv.ne.jp domain).
        ["tcn-catv.ne.jp"] = ("imap.tcn-catv.ne.jp", 993, true),
        // CYBERHOME / FamilyNet Japan: official IMAPS setup for former TEPCO Systems domains.
        // https://www.cyberhome.ne.jp/service/mail/ (port 993, SSL/TLS, full email as login)
        // Includes regional prefixes such as ghtb.tepm.jp via the suffix rules below.
        ["tepm.jp"] = ("imap.cyberhome.ne.jp", 993, true),
        ["nir.jp"] = ("imap.cyberhome.ne.jp", 993, true),
        // catv.ne.jp is a distinct domain; its server is still not verified.
        ["nifty.com"] = ("imap.nifty.com", 993, true),
        ["biglobe.ne.jp"] = ("mail.biglobe.ne.jp", 993, true),
        // Official Japan provider settings (SSL/TLS, port 993)
        ["ocn.ne.jp"] = ("imap.ocn.ne.jp", 993, true),
        ["so-net.ne.jp"] = ("imap.so-net.ne.jp", 993, true), // IMAP option/subscription may be required
        ["plala.or.jp"] = ("imap.plala.or.jp", 993, true),
        ["asahinet.jp"] = ("imap.asahi-net.jp", 993, true),
        ["asahi-net.or.jp"] = ("imap.asahi-net.jp", 993, true),
        ["asahi-net.co.jp"] = ("imap.asahi-net.jp", 993, true),
        ["my.email.ne.jp"] = ("imap.asahi-net.jp", 993, true),
        ["i.softbank.jp"] = ("imap.softbank.jp", 993, true), // E-mail(i), not SoftBank MMS
        ["docomo.ne.jp"] = ("imap.spmode.ne.jp", 993, true), // requires d-account ID and IMAP-specific password
        ["jcom.zaq.ne.jp"] = ("imap.jcom.zaq.ne.jp", 993, true),
        ["jcom.home.ne.jp"] = ("imap.jcom.zaq.ne.jp", 993, true),
        // oct.zaq.ne.jp is a ZAQ domain; shared ZAQ server is a candidate, NOT independently verified for this suffix.
        ["oct.zaq.ne.jp"] = ("imap-f.zaq.ne.jp", 993, true),


        // ──── Indian Providers ────
        ["rediffmail.com"] = ("imap.rediffmail.com", 993, true),

        // ──── Turkish Providers ────
        ["yandex.com.tr"] = ("imap.yandex.com.tr", 993, true),

        // ──── Eastern European ────
        ["wp.pl"] = ("imap.wp.pl", 993, true),
        ["o2.pl"] = ("poczta.o2.pl", 993, true),
        ["onet.pl"] = ("imap.poczta.onet.pl", 993, true),
        ["interia.pl"] = ("poczta.interia.pl", 993, true),
        ["seznam.cz"] = ("imap.seznam.cz", 993, true),
        ["centrum.cz"] = ("imap.centrum.cz", 993, true),
        ["azet.sk"] = ("imap.azet.sk", 993, true),
        ["abv.bg"] = ("imap.abv.bg", 993, true),
        ["ukr.net"] = ("imap.ukr.net", 993, true),
        ["i.ua"] = ("imap.i.ua", 993, true),
        ["meta.ua"] = ("imap.meta.ua", 993, true),

        // ──── Nordic ────
        ["telia.com"] = ("mailbox.telia.com", 993, true),

        // ──── Encrypted / Privacy ────
        ["protonmail.com"] = ("127.0.0.1", 1143, false), // ProtonMail Bridge
        ["proton.me"] = ("127.0.0.1", 1143, false),
        ["tutanota.com"] = ("", 0, false), // No IMAP
        ["tutanota.de"] = ("", 0, false),

        // ──── Others ────
        ["zoho.com"] = ("imap.zoho.com", 993, true),
        ["zoho.eu"] = ("imap.zoho.eu", 993, true),
        ["fastmail.com"] = ("imap.fastmail.com", 993, true),
        ["hushmail.com"] = ("imap.hushmail.com", 993, true),
        ["runbox.com"] = ("mail.runbox.com", 993, true),
        ["mailfence.com"] = ("imap.mailfence.com", 993, true),
        ["mail.com"] = ("imap.mail.com", 993, true),
        ["email.com"] = ("imap.mail.com", 993, true),
        ["usa.com"] = ("imap.mail.com", 993, true),
        ["europe.com"] = ("imap.mail.com", 993, true),
        ["asia.com"] = ("imap.mail.com", 993, true),
        ["consultant.com"] = ("imap.mail.com", 993, true),
        ["engineer.com"] = ("imap.mail.com", 993, true),
        ["writeme.com"] = ("imap.mail.com", 993, true),
        ["dr.com"] = ("imap.mail.com", 993, true),
        ["cheerful.com"] = ("imap.mail.com", 993, true),

        // ──── ISP / Telecom ────
        ["comcast.net"] = ("imap.comcast.net", 993, true),
        ["att.net"] = ("imap.mail.att.net", 993, true),
        ["sbcglobal.net"] = ("imap.mail.att.net", 993, true),
        ["bellsouth.net"] = ("imap.mail.att.net", 993, true),
        ["cox.net"] = ("imap.cox.net", 993, true),
        ["charter.net"] = ("mobile.charter.net", 993, true),
        ["earthlink.net"] = ("imap.earthlink.net", 993, true),
        ["optonline.net"] = ("mail.optonline.net", 993, true),
        ["shaw.ca"] = ("imap.shaw.ca", 993, true),
        ["rogers.com"] = ("imap.rogers.com", 993, true),
        ["sympatico.ca"] = ("imap.mail.yahoo.com", 993, true),
        ["btinternet.com"] = ("imap.mail.yahoo.com", 993, true),
        ["sky.com"] = ("imap.tools.sky.com", 993, true),
        ["ntlworld.com"] = ("imap.tools.sky.com", 993, true),
        ["virginmedia.com"] = ("imap.tools.sky.com", 993, true),
        ["talktalk.net"] = ("imap.talktalk.net", 993, true),
    };

    // Recognized custom-domain email addresses with no provider-verified IMAP host.
    // Do not send credentials to fabricated IMAP names. The login UI will ask
    // for the official incoming mail server under "Use custom IMAP server".
    private static readonly HashSet<string> DomainsRequiringManualSettings = new(StringComparer.OrdinalIgnoreCase)
    {
        "mjct.co.jp", // Japan company domain; official IMAP settings unknown
        "kunimine.jp", // Different domain from kunimine.co.jp; no verified provider IMAP host
    };

    /// <summary>Custom domains requiring an IMAP host confirmed by the mailbox provider.</summary>
    public static bool NeedsManualSettings(string domain) =>
        DomainsRequiringManualSettings.Contains((domain ?? string.Empty).Trim().TrimEnd('.'));


    /// <summary>
    /// Domains whose MX is Microsoft Exchange Online, which rejects simple password IMAP.
    /// The current XVR client supports password IMAP but not Microsoft OAuth 2.0.
    /// </summary>
    public static bool RequiresMicrosoftOAuth(string domain) =>
        string.Equals((domain ?? string.Empty).Trim().TrimEnd('.'),
            "kunimine.co.jp", StringComparison.OrdinalIgnoreCase);

    // Exact provider domains above take priority. Subdomain routing only for confirmed provider-owned suffixes.
    // Never use an unqualified *.jp wildcard, which would route unrelated accounts to a provider's server.
    private static readonly (string Suffix, string Host)[] JapaneseProviderSuffixes =
    {
        ("enjoy.ne.jp", "imaps.enjoy.ne.jp"), // All provider-owned subdomains, e.g. fkym.enjoy.ne.jp
        ("bb4u.ne.jp", "mbox.mose-mail.jp"), // BB4U provider subdomains, e.g. pycm.bb4u.ne.jp
        ("tepm.jp", "imap.cyberhome.ne.jp"), // CYBERHOME, e.g. ghtb.tepm.jp
        ("nir.jp", "imap.cyberhome.ne.jp"), // CYBERHOME, e.g. xxxx.nir.jp
        ("biglobe.ne.jp", "mail.biglobe.ne.jp"),
        ("nifty.com", "imap.nifty.com"),
        ("ocn.ne.jp", "imap.ocn.ne.jp"),
        ("so-net.ne.jp", "imap.so-net.ne.jp"),
        ("plala.or.jp", "imap.plala.or.jp"),
        ("zaq.ne.jp", "imap-f.zaq.ne.jp"), // ZAQ regional fallback; some networks use their own server
    };

    // Legacy DTI domain-to-host routing copied from the provider's published SSL table.
    // Applies only to accounts using the corresponding DTI email system.
    // Source: https://dream.jp/mail/manual/ssl.html
    private static readonly HashSet<string> DtiImap1Domains = new(StringComparer.OrdinalIgnoreCase)
    {
        "alpha.dti2.ne.jp",
        "aqua.dti2.ne.jp",
        "aurora.dti.ne.jp",
        "boreas.dti.ne.jp",
        "ceres.dti.ne.jp",
        "diana.dti.ne.jp",
        "eurus.dti.ne.jp",
        "fides.dti.ne.jp",
        "horae.dti.ne.jp",
        "ice.dti2.ne.jp",
        "iris.dti.ne.jp",
        "island.dti.ne.jp",
        "jade.dti.ne.jp",
        "juno.dti.ne.jp",
        "lares.dti.ne.jp",
        "mars.dti.ne.jp",
        "mist.dti.ne.jp",
        "nona.dti.ne.jp",
        "oak.dti.ne.jp",
        "ocean.dti2.ne.jp",
        "onyx.dti.ne.jp",
        "ops.dti.ne.jp",
        "pluto.dti.ne.jp",
        "po1.dti2.ne.jp",
        "remus.dti.ne.jp",
        "savanna.dti.ne.jp",
        "snow.dti2.ne.jp",
        "sol.dti.ne.jp",
        "splash.dti.ne.jp",
        "squall.dti.ne.jp",
        "terra.dti.ne.jp",
        "uranus.dti.ne.jp",
        "venus.dti.ne.jp",
        "vesta.dti.ne.jp",
        "wave.dti2.ne.jp",
        "wind.dti2.ne.jp",
        "zephyr.dti.ne.jp",
    };

    private static readonly HashSet<string> DtiImap2Domains = new(StringComparer.OrdinalIgnoreCase)
    {
        "agate.dti.ne.jp",
        "air.is.dream.jp",
        "aj.is.dream.jp",
        "am.dream.jp",
        "amber.dti.ne.jp",
        "athena.is.dream.jp",
        "beach.dti.ne.jp",
        "bit.is.dream.jp",
        "breeze.dti.ne.jp",
        "cat.is.dream.jp",
        "charis.is.dream.jp",
        "clio.is.dream.jp",
        "clotho.is.dream.jp",
        "coral.dti.ne.jp",
        "cosmos.dti2.ne.jp",
        "cy.is.dream.jp",
        "dike.is.dream.jp",
        "dm.dream.jp",
        "dream.jp",
        "dx.bw.dream.jp",
        "e-kempo.is.dream.jp",
        "eirene.is.dream.jp",
        "eos.is.dream.jp",
        "erato.is.dream.jp",
        "ex.bw.dream.jp",
        "ex.is.dream.jp",
        "fjs.dream.jp",
        "fly.is.dream.jp",
        "forest.dti2.ne.jp",
        "fox.dti2.ne.jp",
        "gaia.is.dream.jp",
        "galaxy.dti.ne.jp",
        "garnet.dti.ne.jp",
        "gp.is.dream.jp",
        "graces.is.dream.jp",
        "hestia.is.dream.jp",
        "hill.dti.ne.jp",
        "if.dream.jp",
        "ijs.dream.jp",
        "iris.is.dream.jp",
        "iz.dream.jp",
        "jasper.dti.ne.jp",
        "jiec.is.dream.jp",
        "jj.dream.jp",
        "lake.dti.ne.jp",
        "ld.dream.jp",
        "leaf.dti2.ne.jp",
        "ma.point.ne.jp",
        "maple.dti2.ne.jp",
        "mb.point.ne.jp",
        "mc.point.ne.jp",
        "md.point.ne.jp",
        "me.point.ne.jp",
        "mercury.dti.ne.jp",
        "mf.point.ne.jp",
        "mg.point.ne.jp",
        "mh.point.ne.jp",
        "mica.dti.ne.jp",
        "mk.is.dream.jp",
        "ml.dream.jp",
        "moe.is.dream.jp",
        "moon.dti2.ne.jp",
        "muse.dti.ne.jp",
        "mx.bw.dream.jp",
        "mx1.ttcn.ne.jp",
        "mx10.ttcn.ne.jp",
        "mx2.ttcn.ne.jp",
        "mx3.ttcn.ne.jp",
        "mx4.ttcn.ne.jp",
        "mx5.ttcn.ne.jp",
        "mx6.ttcn.ne.jp",
        "mx7.ttcn.ne.jp",
        "mx8.ttcn.ne.jp",
        "mx9.ttcn.ne.jp",
        "nike.is.dream.jp",
        "notus.dti.ne.jp",
        "opal.dti.ne.jp",
        "pandora.is.dream.jp",
        "po.dream.jp",
        "qq.dream.jp",
        "rainbow.dti.ne.jp",
        "river.dti.ne.jp",
        "rj.dream.jp",
        "ruby.dti.ne.jp",
        "sala.dti.ne.jp",
        "sala2.dti.ne.jp",
        "saturn.dti.ne.jp",
        "sc.dream.jp",
        "sea.is.dream.jp",
        "selene.is.dream.jp",
        "sky.dti2.ne.jp",
        "sky.is.dream.jp",
        "spn1.speednet.ne.jp",
        "spn2.speednet.ne.jp",
        "spn3.speednet.ne.jp",
        "spn4.speednet.ne.jp",
        "spn5.speednet.ne.jp",
        "spn6.speednet.ne.jp",
        "spn7.speednet.ne.jp",
        "spn8.speednet.ne.jp",
        "spn9.speednet.ne.jp",
        "ss.dream.jp",
        "star.dti2.ne.jp",
        "sun.is.dream.jp",
        "sw.is.dream.jp",
        "thalia.is.dream.jp",
        "themis.is.dream.jp",
        "thunder.dti.ne.jp",
        "titan.is.dream.jp",
        "topaz.dti.ne.jp",
        "triton.is.dream.jp",
        "tyche.is.dream.jp",
        "urania.is.dream.jp",
        "valley.dti.ne.jp",
        "wood.dti2.ne.jp",
        "wp.dream.jp",
        "zeus.is.dream.jp",
    };

    /// <summary>
    /// Get IMAP server info for a domain. Falls back to common hostname patterns.
    /// </summary>
    public static List<(string Host, int Port, bool UseSsl)> GetServersForDomain(string domain)
    {
        // Case-insensitive matching for domain input. No credentials are logged or stored.
        domain = (domain ?? string.Empty).Trim().TrimEnd('.').ToLowerInvariant();
        var results = new List<(string Host, int Port, bool UseSsl)>();
        if (domain.Length == 0) return results;

        if (DtiImap1Domains.Contains(domain))
            return new() { ("imap.cm.dream.jp", 993, true) };
        if (DtiImap2Domains.Contains(domain))
            return new() { ("imap2.cm.dream.jp", 993, true) };

        if (NeedsManualSettings(domain))
            return results; // No guessing for company domains with unknown provider configuration.

        if (Servers.TryGetValue(domain, out var known))
        {
            if (!string.IsNullOrEmpty(known.Host))
                results.Add(known);
            return results;
        }

        foreach (var (suffix, host) in JapaneseProviderSuffixes)
        {
            if (domain.EndsWith("." + suffix, StringComparison.OrdinalIgnoreCase))
            {
                results.Add((host, 993, true));
                return results;
            }
        }

        // Fallback: try common IMAP hostname patterns
        results.Add(($"imap.{domain}", 993, true));
        results.Add(($"mail.{domain}", 993, true));
        results.Add(($"imap.{domain}", 143, false));
        results.Add(($"mailstore.{domain}", 993, true));

        return results;
    }
}
