using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using MimeKit;
using MailViewer.Core.Providers;

namespace MailViewer.Core.Inbox;

/// <summary>
/// IMAP session: reading is read-only; explicit confirmed actions may change Trash.
/// Passwords are retained only in process memory during
/// the active session so that a single dropped connection can be re-established;
/// they are never persisted to disk or included in logs.
/// </summary>
public sealed class ImapInboxClient : IDisposable
{
    private ImapClient? _client;
    // A MailKit IMAP connection processes one command at a time. Background folder
    // discovery must not overlap with message reads on the same socket.
    private readonly SemaphoreSlim _commandGate = new(1, 1);
    private string? _sessionEmail;
    private string? _sessionPassword;
    private string? _sessionImapUsername;
    private (string Host, int Port, bool UseSsl)? _server;

    public bool IsConnected => _client?.IsConnected == true && _client.IsAuthenticated;
    public string ConnectedHost { get; private set; } = string.Empty;
    public string LastError { get; private set; } = string.Empty;
    // Cached count from the folder already OPENed for the fast header list.
    // This avoids additional slow IMAP STATUS calls just to show a folder badge.
    public string LastOpenedFolderFullName { get; private set; } = string.Empty;
    public int LastOpenedFolderCount { get; private set; } = -1;

    public Task<bool> ConnectAsync(string email, string password, CancellationToken ct = default,
        string? imapUsername = null)
    {
        var domain = email.Trim().Split('@').LastOrDefault() ?? string.Empty;
        return ConnectCandidatesAsync(email, password, ImapServerMap.GetServersForDomain(domain), ct, imapUsername);
    }

    public Task<bool> ConnectToServerAsync(string email, string password, string host,
        int port, bool startTls, CancellationToken ct = default, string? imapUsername = null)
    {
        var servers = new List<(string Host, int Port, bool UseSsl)> { (host.Trim(), port, !startTls) };
        return ConnectCandidatesAsync(email, password, servers, ct, imapUsername);
    }

    private async Task<bool> ConnectCandidatesAsync(string email, string password,
        IEnumerable<(string Host, int Port, bool UseSsl)> servers, CancellationToken ct,
        string? imapUsername)
    {
        DisposeConnection();
        ClearSession();
        LastError = string.Empty;
        ConnectedHost = string.Empty;

        foreach (var server in servers)
        {
            ct.ThrowIfCancellationRequested();
            if (string.IsNullOrWhiteSpace(server.Host) || server.Port is < 1 or > 65535)
                continue;

            var client = CreateClient();
            try
            {
                var mode = server.UseSsl ? SecureSocketOptions.SslOnConnect : SecureSocketOptions.StartTls;
                await client.ConnectAsync(server.Host, server.Port, mode, ct);
                await client.AuthenticateAsync(
                    string.IsNullOrWhiteSpace(imapUsername) ? email.Trim() : imapUsername.Trim(), password, ct);
                _client = client;
                _server = server;
                _sessionEmail = email.Trim();
                _sessionPassword = password;
                _sessionImapUsername = imapUsername;
                ConnectedHost = $"{server.Host}:{server.Port}";
                LastError = string.Empty;
                return true;
            }
            catch (OperationCanceledException)
            {
                client.Dispose();
                throw;
            }
            catch (MailKit.Security.AuthenticationException)
            {
                // A rejected login is not a hostname-discovery problem. Do not
                // try alternate servers repeatedly (risk of an account lockout).
                LastError = $"{server.Host}:{server.Port} — Authentication rejected by the IMAP server.";
                client.Dispose();
                return false;
            }
            catch (Exception ex)
            {
                LastError = $"{server.Host}:{server.Port} — {ex.Message}";
                client.Dispose();
            }
        }

        if (string.IsNullOrWhiteSpace(LastError))
            LastError = "No usable IMAP server was found for this domain.";
        return false;
    }

    private static ImapClient CreateClient() => new() { Timeout = 20000 };

    private async Task ReconnectAsync(CancellationToken ct)
    {
        if (_server is not { } server || _sessionEmail is null || _sessionPassword is null)
            throw new InvalidOperationException("IMAP connection ended. Disconnect and sign in again.");

        DisposeConnection();
        var fresh = CreateClient();
        try
        {
            var mode = server.UseSsl ? SecureSocketOptions.SslOnConnect : SecureSocketOptions.StartTls;
            await fresh.ConnectAsync(server.Host, server.Port, mode, ct);
            await fresh.AuthenticateAsync(
                string.IsNullOrWhiteSpace(_sessionImapUsername) ? _sessionEmail : _sessionImapUsername.Trim(),
                _sessionPassword, ct);
            _client = fresh;
            ConnectedHost = $"{server.Host}:{server.Port}";
        }
        catch
        {
            fresh.Dispose();
            throw;
        }
    }

    // One safe retry for a dropped connection. Used ONLY for read operations.
    private async Task<T> ReadWithReconnectAsync<T>(
        Func<ImapClient, CancellationToken, Task<T>> action, CancellationToken ct)
    {
        await _commandGate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            for (var attempt = 0; attempt < 2; attempt++)
            {
                ct.ThrowIfCancellationRequested();
                if (!IsConnected)
                    await ReconnectAsync(ct).ConfigureAwait(false);
                try
                {
                    return await action(_client!, ct).ConfigureAwait(false);
                }
                catch (Exception ex) when (attempt == 0 && !ct.IsCancellationRequested && IsConnectionFailure(ex))
                {
                    await ReconnectAsync(ct).ConfigureAwait(false);
                }
            }

            throw new InvalidOperationException("Unable to read from the IMAP server after reconnecting.");
        }
        finally
        {
            _commandGate.Release();
        }
    }

    private bool IsConnectionFailure(Exception ex) =>
        ex is IOException or SocketException or ImapProtocolException or
            ServiceNotConnectedException or ServiceNotAuthenticatedException ||
        (ex is InvalidOperationException && !IsConnected);

    public Task<List<InboxFolderInfo>> GetFoldersAsync(CancellationToken ct = default) =>
        ReadWithReconnectAsync(async (client, token) =>
        {
            var folders = new List<InboxFolderInfo>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            void AddFolder(IMailFolder folder)
            {
                if (!seen.Add(folder.FullName) || (folder.Attributes & FolderAttributes.NoSelect) != 0)
                    return;
                // Do not issue STATUS requests on each folder. Counts are populated
                // from OPEN/EXAMINE when a user actually reads that folder.
                folders.Add(new InboxFolderInfo { Name = folder.Name, FullPath = folder.FullName });
            }

            AddFolder(client.Inbox);
            foreach (var ns in client.PersonalNamespaces)
            {
                token.ThrowIfCancellationRequested();
                var root = client.GetFolder(ns);
                var children = await root.GetSubfoldersAsync(false, token);
                foreach (var folder in children)
                    AddFolder(folder);
            }
            return folders;
        }, ct);

    private static async Task<IMailFolder> ResolveFolderAsync(
        ImapClient client, string folderName, CancellationToken ct)
    {
        if (string.Equals(folderName, "INBOX", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(folderName, client.Inbox.FullName, StringComparison.OrdinalIgnoreCase))
            return client.Inbox;
        return await client.GetFolderAsync(folderName, ct);
    }

    // Offset 0 = 25 newest messages; offset 25 = next older 25 messages.
    // The UI combines the pages without refetching previously shown headers.
    public Task<List<InboxMessageSummary>> GetMessagesAsync(string folderName,
        int count = 25, CancellationToken ct = default) =>
        GetMessagesPageAsync(folderName, 0, count, ct);

    public Task<List<InboxMessageSummary>> GetMessagesPageAsync(string folderName,
        int skipNewest, int pageSize = 25, CancellationToken ct = default) =>
        ReadWithReconnectAsync(async (client, token) =>
        {
            var folder = await ResolveFolderAsync(client, folderName, token);
            if (!folder.IsOpen)
                await folder.OpenAsync(FolderAccess.ReadOnly, token);
            LastOpenedFolderFullName = folder.FullName;
            LastOpenedFolderCount = folder.Count;
            var skip = Math.Max(0, skipNewest);
            if (folder.Count == 0 || skip >= folder.Count)
                return new List<InboxMessageSummary>();

            var lastIndex = folder.Count - skip - 1;
            var firstIndex = Math.Max(0, lastIndex - Math.Clamp(pageSize, 1, 100) + 1);
            // Read only ENVELOPE and FLAGS; no message bodies or PreviewText.
            var summaries = await folder.FetchAsync(firstIndex, lastIndex,
                MessageSummaryItems.UniqueId | MessageSummaryItems.Envelope |
                MessageSummaryItems.Flags, token);
            return summaries.OrderByDescending(s => s.Index).Select(ToRow).ToList();
        }, ct);

    public Task<InboxMessageDetail> GetMessageDetailAsync(string folderName,
        uint uid, CancellationToken ct = default) =>
        ReadWithReconnectAsync(async (client, token) =>
        {
            var folder = await ResolveFolderAsync(client, folderName, token);
            if (!folder.IsOpen)
                await folder.OpenAsync(FolderAccess.ReadOnly, token);
            var message = await folder.GetMessageAsync(new UniqueId(uid), token);
            var detail = new InboxMessageDetail
            {
                Uid = uid,
                Subject = message.Subject ?? "(No subject)",
                From = message.From?.ToString() ?? string.Empty,
                To = message.To?.ToString() ?? string.Empty,
                Date = message.Date.UtcDateTime,
                TextBody = !string.IsNullOrWhiteSpace(message.TextBody)
                    ? message.TextBody : HtmlToPlainText(message.HtmlBody ?? string.Empty),
                HtmlBody = message.HtmlBody ?? string.Empty // Sanitized and rendered only by the UI.
            };
            // Resolve embedded CID images only. Never download externally hosted content.
            // Restrict memory use for messages with many or very large inline attachments.
            var totalInlineBytes = 0L;
            foreach (var part in message.BodyParts.OfType<MimePart>())
            {
                if (string.IsNullOrWhiteSpace(part.ContentId) || part.Content is null)
                    continue;
                var mime = part.ContentType.MimeType.ToLowerInvariant();
                if (mime is not ("image/png" or "image/jpeg" or "image/gif" or "image/webp"))
                    continue;
                if (detail.InlineImages.Count >= 24 || totalInlineBytes >= 16 * 1024 * 1024)
                    break;
                using var stream = new MemoryStream();
                part.Content.DecodeTo(stream);
                if (stream.Length == 0 || stream.Length > 5 * 1024 * 1024 ||
                    totalInlineBytes + stream.Length > 16 * 1024 * 1024)
                    continue;
                var cid = part.ContentId.Trim().Trim('<', '>');
                if (cid.Length == 0) continue;
                detail.InlineImages[cid] = new InlineImageData
                {
                    MimeType = mime, Bytes = stream.ToArray()
                };
                totalInlineBytes += stream.Length;
            }
            foreach (var attachment in message.Attachments)
                if (attachment is MimePart part && !string.IsNullOrWhiteSpace(part.FileName))
                    detail.Attachments.Add(part.FileName);
            return detail;
        }, ct);

    public Task<List<InboxMessageSummary>> SearchMessagesAsync(string folderName,
        string query, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(query))
            return Task.FromResult(new List<InboxMessageSummary>());
        return ReadWithReconnectAsync(async (client, token) =>
        {
            var folder = await ResolveFolderAsync(client, folderName, token);
            if (!folder.IsOpen)
                await folder.OpenAsync(FolderAccess.ReadOnly, token);
            // Fast search: BODY searches can scan every full message and hang on
            // large mailboxes. Use only FROM and SUBJECT headers.
            var predicate = SearchQuery.Or(
                SearchQuery.SubjectContains(query), SearchQuery.FromContains(query));
            var uids = await folder.SearchAsync(predicate, token);
            if (uids.Count == 0)
                return new List<InboxMessageSummary>();
            var latest = uids.Count > 50 ? uids.Skip(uids.Count - 50).ToList() : uids.ToList();
            var summaries = await folder.FetchAsync(latest,
                MessageSummaryItems.UniqueId | MessageSummaryItems.Envelope |
                MessageSummaryItems.Flags, token);
            return summaries.OrderByDescending(s => s.Index).Select(ToRow).ToList();
        }, ct);
    }

    // Delete is deliberately a MOVE TO TRASH, never an expunge action.
    // Writes are NOT retried after a network failure: the server may have
    // completed the move before the connection dropped.
    public async Task<int> MoveMessageToTrashAsync(string sourceFolderName, uint uid,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(sourceFolderName) || uid == 0)
            throw new ArgumentException("Select a valid email before deleting.");

        await _commandGate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected)
                await ReconnectAsync(ct).ConfigureAwait(false);
            var client = _client!;
            var source = await ResolveFolderAsync(client, sourceFolderName, ct).ConfigureAwait(false);
            var trash = await FindTrashFolderAsync(client, ct).ConfigureAwait(false);
            if (trash is null)
                throw new InvalidOperationException(
                    "Trash folder not found on this account. No email was deleted.");
            if (string.Equals(source.FullName, trash.FullName, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException(
                    "This email is already in Trash. Permanent deletion is not available in XVR.");

            if (!source.IsOpen || source.Access != FolderAccess.ReadWrite)
            {
                var access = await source.OpenAsync(FolderAccess.ReadWrite, ct).ConfigureAwait(false);
                if (access != FolderAccess.ReadWrite)
                    throw new InvalidOperationException(
                        "The server does not allow changes to this folder. No email was deleted.");
            }

            // No fallback to marking \Deleted or expunging. MailKit handles
            // server-specific MOVE semantics and destination UID mapping.
            await source.MoveToAsync(new UniqueId(uid), trash, ct).ConfigureAwait(false);
            LastOpenedFolderFullName = source.FullName;
            LastOpenedFolderCount = source.Count;
            return source.Count;
        }
        finally
        {
            _commandGate.Release();
        }
    }

    // Destructive operations never use ReadWithReconnectAsync: a timeout after STORE
    // or EXPUNGE does not tell us whether the server already completed the action.
    // For a single message we REQUIRE UIDPLUS; MailKit otherwise emulates UID
    // EXPUNGE by modifying \Deleted flags on other messages, which we won't do.
    public async Task<int> PermanentlyDeleteFromTrashAsync(string trashFolderName, uint uid,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(trashFolderName) || uid == 0)
            throw new ArgumentException("Select an email in Trash before deleting permanently.");

        await _commandGate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected)
                await ReconnectAsync(ct).ConfigureAwait(false);
            var client = _client!;
            var trash = await VerifyTrashFolderAsync(client, trashFolderName, ct).ConfigureAwait(false);
            if ((client.Capabilities & ImapCapabilities.UidPlus) == 0)
                throw new NotSupportedException(
                    "This IMAP server does not support safe per-message permanent deletion (UIDPLUS). " +
                    "Use Empty Trash if you intend to remove every message from Trash.");

            if (!trash.IsOpen || trash.Access != FolderAccess.ReadWrite)
            {
                var access = await trash.OpenAsync(FolderAccess.ReadWrite, ct).ConfigureAwait(false);
                if (access != FolderAccess.ReadWrite)
                    throw new InvalidOperationException("Trash is read-only on this server.");
            }
            var target = new UniqueId(uid);
            var matching = await trash.FetchAsync(new List<UniqueId> { target },
                MessageSummaryItems.UniqueId, ct).ConfigureAwait(false);
            if (matching.Count == 0)
                throw new InvalidOperationException("This message is no longer in Trash. Refresh the list.");

            await trash.AddFlagsAsync(target, MessageFlags.Deleted, true, ct).ConfigureAwait(false);
            await trash.ExpungeAsync(new List<UniqueId> { target }, ct).ConfigureAwait(false);
            LastOpenedFolderFullName = trash.FullName;
            LastOpenedFolderCount = trash.Count;
            return trash.Count;
        }
        finally
        {
            _commandGate.Release();
        }
    }

    // Empty Trash intentionally removes ALL emails in that folder (including
    // messages not visible in the first 25-item page). The caller confirms it.
    // No commands are sent to Inbox, Junk, Sent or any other folder.
    public async Task<int> EmptyTrashAsync(string trashFolderName, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(trashFolderName))
            throw new ArgumentException("Select the Trash folder first.");

        await _commandGate.WaitAsync(ct).ConfigureAwait(false);
        try
        {
            if (!IsConnected)
                await ReconnectAsync(ct).ConfigureAwait(false);
            var client = _client!;
            var trash = await VerifyTrashFolderAsync(client, trashFolderName, ct).ConfigureAwait(false);
            if (!trash.IsOpen || trash.Access != FolderAccess.ReadWrite)
            {
                var access = await trash.OpenAsync(FolderAccess.ReadWrite, ct).ConfigureAwait(false);
                if (access != FolderAccess.ReadWrite)
                    throw new InvalidOperationException("Trash is read-only on this server.");
            }

            var allUids = await trash.SearchAsync(SearchQuery.All, ct).ConfigureAwait(false);
            if (allUids.Count == 0)
            {
                LastOpenedFolderFullName = trash.FullName;
                LastOpenedFolderCount = trash.Count;
                return 0;
            }

            // Flag all messages in Trash (not any other folder) before expunging.
            // On an interrupted write there is intentionally no auto-retry.
            await trash.AddFlagsAsync(allUids, MessageFlags.Deleted, true, ct).ConfigureAwait(false);
            await trash.ExpungeAsync(ct).ConfigureAwait(false);
            LastOpenedFolderFullName = trash.FullName;
            LastOpenedFolderCount = trash.Count;
            return allUids.Count;
        }
        finally
        {
            _commandGate.Release();
        }
    }

    private static async Task<IMailFolder> VerifyTrashFolderAsync(
        ImapClient client, string selectedFolderName, CancellationToken ct)
    {
        // Require that the selected folder is the server's real Trash folder.
        // A user-created folder coincidentally named Trash isn't sufficient.
        var verifiedTrash = await FindTrashFolderAsync(client, ct).ConfigureAwait(false);
        if (verifiedTrash is null ||
            !string.Equals(verifiedTrash.FullName, selectedFolderName,
                StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                "The selected folder is not the account's verified Trash folder. Nothing was removed.");
        return verifiedTrash;
    }

    private static async Task<IMailFolder?> FindTrashFolderAsync(
        ImapClient client, CancellationToken ct)
    {
        // Prefer IMAP SPECIAL-USE / XLIST when the provider offers it.
        try
        {
            var special = client.GetFolder(SpecialFolder.Trash);
            if (special?.Exists == true && special.CanOpen)
                return special;
        }
        catch (NotSupportedException) { }

        // Older Japanese and corporate providers may not advertise SPECIAL-USE.
        // Only accept an explicitly named or Trash-flagged existing folder.
        var candidates = new List<IMailFolder>();
        foreach (var ns in client.PersonalNamespaces)
        {
            var root = client.GetFolder(ns);
            var folders = await root.GetSubfoldersAsync(false, ct).ConfigureAwait(false);
            candidates.AddRange(folders.Where(f => f.Exists && f.CanOpen));
        }
        var flagged = candidates.FirstOrDefault(f =>
            (f.Attributes & FolderAttributes.Trash) != 0);
        if (flagged is not null) return flagged;
        string[] names = { "Trash", "Deleted Items", "Deleted Messages", "Deleted", "Bin",
            "ゴミ箱", "ごみ箱", "削除済みアイテム", "削除済み", "已删除", "已刪除" };
        return candidates.FirstOrDefault(f => names.Any(n =>
            string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)));
    }

    private static InboxMessageSummary ToRow(IMessageSummary summary)
    {
        var from = summary.Envelope?.From?.ToString() ?? string.Empty;
        var name = summary.Envelope?.From?.Mailboxes.FirstOrDefault()?.Name;
        return new InboxMessageSummary
        {
            Uid = summary.UniqueId.Id,
            Subject = summary.Envelope?.Subject ?? "(No subject)",
            From = from,
            FromName = string.IsNullOrWhiteSpace(name) ? from : name,
            Date = summary.Envelope?.Date?.UtcDateTime ?? DateTime.MinValue,
            IsRead = (summary.Flags.GetValueOrDefault() & MessageFlags.Seen) != 0,
            PreviewSnippet = string.Empty // Fast mode: body downloaded only when email selected.
        };
    }

    private static string HtmlToPlainText(string html)
    {
        if (string.IsNullOrWhiteSpace(html))
            return "(This message has no text body.)";
        html = Regex.Replace(html, @"(?is)<(script|style|head)\b[^>]*>.*?</\1\s*>", " ");
        html = Regex.Replace(html, @"(?i)<br\s*/?>|</p\s*>|</div\s*>|</li\s*>", "\n");
        html = Regex.Replace(html, @"(?s)<[^>]+>", " ");
        return WebUtility.HtmlDecode(html).Trim();
    }

    private void DisposeConnection()
    {
        var old = _client;
        _client = null;
        // Dispose the socket immediately instead of blocking the UI waiting for LOGOUT.
        old?.Dispose();
    }

    private void ClearSession()
    {
        _sessionEmail = null;
        _sessionPassword = null;
        _sessionImapUsername = null;
        _server = null;
    }

    public void Dispose()
    {
        DisposeConnection();
        ClearSession();
        ConnectedHost = string.Empty;
        LastOpenedFolderFullName = string.Empty;
        LastOpenedFolderCount = -1;
    }
}
