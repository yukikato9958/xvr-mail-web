using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace MailViewer.Core.Inbox;

public sealed class InboxFolderInfo : INotifyPropertyChanged
{
    public string Name { get; set; } = string.Empty;
    public string FullPath { get; set; } = string.Empty;

    // Unknown is null, not zero. Only show a total once the folder has been opened.
    private int? _totalCount;
    public int? TotalCount
    {
        get => _totalCount;
        set
        {
            if (_totalCount == value) return;
            _totalCount = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(CountLabel));
        }
    }

    public string CountLabel => TotalCount.HasValue ? $"{TotalCount:N0} emails" : string.Empty;
    public int UnreadCount { get; set; } = -1;
    public string UnreadLabel => UnreadCount < 0 ? string.Empty : $"{UnreadCount} unread";

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
