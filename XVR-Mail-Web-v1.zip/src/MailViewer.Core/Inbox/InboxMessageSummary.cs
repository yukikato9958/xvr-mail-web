using System;
using System.Collections.Generic;

namespace MailViewer.Core.Inbox
{
    public class InboxMessageSummary
    {
        public uint Uid { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string From { get; set; } = string.Empty;
        public string FromName { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public bool IsRead { get; set; }
        public string PreviewSnippet { get; set; } = string.Empty;
    }
}
