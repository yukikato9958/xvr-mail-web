namespace MailViewer.Core.Inbox;

public sealed class InlineImageData
{
    public string MimeType { get; init; } = "image/png";
    public byte[] Bytes { get; init; } = System.Array.Empty<byte>();
}
