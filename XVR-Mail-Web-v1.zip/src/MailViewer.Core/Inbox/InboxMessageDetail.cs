using System;
using System.Collections.Generic;

namespace MailViewer.Core.Inbox
{
    public class InboxMessageDetail
    {
        public uint Uid { get; set; }
        public string Subject { get; set; } = string.Empty;
        public string From { get; set; } = string.Empty;
        public string To { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string TextBody { get; set; } = string.Empty;
        public string HtmlBody { get; set; } = string.Empty;
        public List<string> Attachments { get; set; } = new();
        // Inline CID images from the selected email, never stored on disk.
        public Dictionary<string, InlineImageData> InlineImages { get; set; } =
            new(StringComparer.OrdinalIgnoreCase);
    }
}
