@echo off
cd /d "%~dp0"
echo Starting XVR Mail Web at http://localhost:5080
dotnet run --project XVR.Web.csproj --urls http://localhost:5080
pause
