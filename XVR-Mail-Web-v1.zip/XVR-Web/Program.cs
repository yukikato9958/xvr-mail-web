using MailViewer.Core.Inbox;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<MailSession>();
var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapGet("/api/status", (MailSession s) => Results.Ok(new { connected = s.Client?.IsConnected == true, host = s.Client?.ConnectedHost ?? "" }));
app.MapPost("/api/connect", async (LoginRequest req, MailSession s, CancellationToken ct) => {
    if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Password)) return Results.BadRequest(new { error = "Email and password are required." });
    s.Reset(); s.Client = new ImapInboxClient();
    bool ok = string.IsNullOrWhiteSpace(req.Server)
        ? await s.Client.ConnectAsync(req.Email.Trim(), req.Password, ct, req.Username)
        : await s.Client.ConnectToServerAsync(req.Email.Trim(), req.Password, req.Server.Trim(), req.Port <= 0 ? 993 : req.Port, req.StartTls, ct, req.Username);
    if (!ok) { var msg = s.Client.LastError; s.Reset(); return Results.BadRequest(new { error = msg }); }
    return Results.Ok(new { connected = true, host = s.Client.ConnectedHost });
});
app.MapPost("/api/disconnect", (MailSession s) => { s.Reset(); return Results.Ok(new { disconnected = true }); });
app.MapGet("/api/folders", async (MailSession s, CancellationToken ct) => {
    if (s.Client?.IsConnected != true) return Results.Unauthorized();
    try { var f = await s.Client.GetFoldersAsync(ct); return Results.Ok(f.Select(x => new { name = x.Name, path = x.FullPath })); }
    catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
});
app.MapGet("/api/messages", async (string folder, int? skip, int? take, MailSession s, CancellationToken ct) => {
    if (s.Client?.IsConnected != true) return Results.Unauthorized();
    try { var rows = await s.Client.GetMessagesPageAsync(folder, Math.Max(0, skip ?? 0), Math.Clamp(take ?? 25, 1, 50), ct); return Results.Ok(new { messages = rows, total = s.Client.LastOpenedFolderCount }); }
    catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
});
app.MapGet("/api/search", async (string folder, string q, MailSession s, CancellationToken ct) => {
    if (s.Client?.IsConnected != true) return Results.Unauthorized();
    try { return Results.Ok(await s.Client.SearchMessagesAsync(folder, q, ct)); }
    catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
});
app.MapGet("/api/message", async (string folder, uint uid, MailSession s, CancellationToken ct) => {
    if (s.Client?.IsConnected != true) return Results.Unauthorized();
    try { return Results.Ok(await s.Client.GetMessageDetailAsync(folder, uid, ct)); }
    catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
});
app.MapPost("/api/trash", async (ActionRequest req, MailSession s, CancellationToken ct) => {
    if (s.Client?.IsConnected != true) return Results.Unauthorized();
    try { var count = await s.Client.MoveMessageToTrashAsync(req.Folder, req.Uid, ct); return Results.Ok(new { count }); }
    catch (Exception ex) { return Results.BadRequest(new { error = ex.Message }); }
});
app.MapFallbackToFile("index.html");
app.Run();

record LoginRequest(string Email, string Password, string? Username, string? Server, int Port = 993, bool StartTls = false);
record ActionRequest(string Folder, uint Uid);
sealed class MailSession { public ImapInboxClient? Client { get; set; } public void Reset() { Client?.Dispose(); Client = null; } }
