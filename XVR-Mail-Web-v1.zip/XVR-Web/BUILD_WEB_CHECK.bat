@echo off
cd /d "%~dp0"
dotnet restore XVR.Web.csproj
if errorlevel 1 exit /b 1
dotnet build XVR.Web.csproj -c Release
pause
