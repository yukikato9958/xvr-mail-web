# XVR Mail Web

A browser-based adaptation of the supplied XVR WPF project. The original MailViewer.Core IMAP engine and provider map are reused; the WPF desktop UI is replaced by a responsive dark web UI.

## Features
- IMAP sign-in with automatic provider mapping and optional custom IMAP host/username.
- Folder discovery, paged recent-message list, sender/subject search, message reader.
- Plain-text and isolated HTML views. External images are blocked unless the user confirms for the current message.
- HTML viewer uses a sandboxed iframe, strips scripts/forms/embedded frames/styles, removes links, and does not permit navigation.
- Embedded CID image data can be resolved in the viewer; external content is not fetched by default.
- Delete action moves the selected message to server Trash using the existing safe MailKit implementation.
- Password and IMAP session remain in server process memory only; disconnect clears the session.

## Requirements
- .NET 10 SDK on the machine hosting the web app.
- Internet access for NuGet restore and IMAP access.
- A modern browser on the same machine or trusted private network.

## Run (Windows)
1. Extract this ZIP.
2. Install .NET 10 SDK.
3. Run `RUN_WEB.bat`.
4. Open `http://localhost:5080` in a browser.

## Important deployment/security notes
This initial web edition is intended for a single-user local/private deployment. It uses one in-memory IMAP session shared by the web process and does not include web-user authentication, per-user session isolation, HTTPS termination, SMTP sending, or password persistence. Do not expose port 5080 directly to the public internet. For remote access, put it behind HTTPS and strong authentication, and add per-user server-side session isolation first.

The original XVR core is read-oriented. This web version retains the explicit Move to Trash operation; it does not send, reply, or forward email. Search is limited to sender/from and subject headers to avoid slow full-body scans. Provider mappings are candidates; successful authentication depends on provider settings and app-password/IMAP enablement.

## Build
From this directory:

```powershell
dotnet restore XVR.Web.csproj
dotnet build XVR.Web.csproj -c Release
dotnet run --project XVR.Web.csproj --urls http://localhost:5080
```

This source archive has not been compiled or live-tested in this environment because the .NET SDK and real IMAP credentials are unavailable here.
